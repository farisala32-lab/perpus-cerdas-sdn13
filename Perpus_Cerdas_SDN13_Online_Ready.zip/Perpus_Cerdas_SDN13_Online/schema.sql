-- PERPUS CERDAS SDN NO. 13 KOTA BARAT
-- Jalankan di Supabase SQL Editor pada project sekolah yang benar.
-- Setelah menjalankan SQL, buat akun pertama melalui Supabase Auth > Users,
-- lalu atur profil admin menggunakan langkah di README.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student' check (role in ('admin','librarian','teacher','student')),
  class_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.books (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author text,
  category text not null default 'Cerita Anak',
  grade_range text not null default '1–6',
  book_type text not null check (book_type in ('digital','physical')),
  cover_emoji text default '📘',
  access_url text,
  description text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint digital_book_url check (book_type <> 'digital' or access_url is null or access_url ~ '^https://')
);

create table if not exists public.loans (
  id uuid primary key default gen_random_uuid(),
  borrower_name text not null,
  class_name text,
  book_title text not null,
  borrowed_at date not null default current_date,
  due_date date,
  returned_at date,
  status text not null default 'Dipinjam' check (status in ('Dipinjam','Dikembalikan')),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.reading_journals (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references auth.users(id) on delete cascade,
  student_name text not null,
  class_name text,
  book_title text not null,
  reading_date date not null default current_date,
  summary text not null,
  teacher_feedback text,
  created_at timestamptz not null default now()
);

create or replace function public.current_role()
returns text language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_role() in ('admin','librarian','teacher'), false) $$;

alter table public.profiles enable row level security;
alter table public.books enable row level security;
alter table public.loans enable row level security;
alter table public.reading_journals enable row level security;

drop policy if exists "profiles read self or staff" on public.profiles;
create policy "profiles read self or staff" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_staff());

drop policy if exists "admin update profiles" on public.profiles;
create policy "admin update profiles" on public.profiles for update to authenticated
using (public.current_role() = 'admin') with check (public.current_role() = 'admin');

drop policy if exists "authenticated read books" on public.books;
create policy "authenticated read books" on public.books for select to authenticated using (true);

drop policy if exists "librarian admin manage books" on public.books;
create policy "librarian admin manage books" on public.books for all to authenticated
using (public.current_role() in ('admin','librarian'))
with check (public.current_role() in ('admin','librarian'));

drop policy if exists "staff read loans" on public.loans;
create policy "staff read loans" on public.loans for select to authenticated
using (public.current_role() in ('admin','librarian','teacher'));

drop policy if exists "staff insert loans" on public.loans;
create policy "staff insert loans" on public.loans for insert to authenticated
with check (public.current_role() in ('admin','librarian') and created_by = auth.uid());

drop policy if exists "staff update loans" on public.loans;
create policy "staff update loans" on public.loans for update to authenticated
using (public.current_role() in ('admin','librarian'))
with check (public.current_role() in ('admin','librarian'));

drop policy if exists "students read own journals and staff read class journals" on public.reading_journals;
create policy "students read own journals and staff read class journals" on public.reading_journals for select to authenticated
using (student_id = auth.uid() or public.is_staff());

drop policy if exists "students insert own journals" on public.reading_journals;
create policy "students insert own journals" on public.reading_journals for insert to authenticated
with check (student_id = auth.uid());

drop policy if exists "staff feedback journals" on public.reading_journals;
create policy "staff feedback journals" on public.reading_journals for update to authenticated
using (public.current_role() in ('admin','librarian','teacher'))
with check (public.current_role() in ('admin','librarian','teacher'));

-- Profiles are deliberately NOT auto-promoted. Assign roles only from a trusted admin session/SQL Editor.
