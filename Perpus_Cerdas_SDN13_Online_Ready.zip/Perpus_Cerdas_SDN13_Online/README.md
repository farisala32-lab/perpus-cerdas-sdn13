# Perpus Cerdas — SDN No. 13 Kota Barat (Online-ready)

## Apa yang tersedia
- `index.html`: aplikasi web yang siap dikonfigurasi ke Supabase.
- `schema.sql`: tabel database dan Row Level Security (RLS).
- Fitur: login, katalog buku digital/fisik, pencarian, CRUD buku untuk admin/pustakawan, peminjaman/pengembalian, jurnal membaca, laporan CSV, dan tampilan responsif.

## Status yang jujur
Paket ini adalah **implementasi siap konfigurasi**, belum diterbitkan online dan belum tersambung ke project Supabase milik sekolah. Saya tidak memiliki akses atau kredensial akun hosting/database sekolah, jadi tidak dapat mengaktifkan deployment atas nama sekolah dari sini. Jangan mengirimkan password atau secret key ke chat.

## A. Buat project database
1. Buka https://supabase.com dan masuk/daftar.
2. Buat project baru bernama `perpus-cerdas-sdn13` dan simpan password database di tempat aman.
3. Buka **SQL Editor**, buat query baru, salin seluruh isi `schema.sql`, lalu jalankan.
4. Buka **Project Settings → API** (atau halaman API Keys pada dashboard terbaru). Salin Project URL dan `anon`/publishable key. **Jangan gunakan `service_role` key di browser.**

## B. Hubungkan aplikasi
1. Buka `index.html` dengan editor teks.
2. Temukan dua baris berikut:
   `const SUPABASE_URL='GANTI_DENGAN_SUPABASE_PROJECT_URL';`
   `const SUPABASE_ANON_KEY='GANTI_DENGAN_SUPABASE_ANON_KEY';`
3. Ganti nilai pertama dengan Project URL, dan nilai kedua dengan anon/publishable key dari project sekolah.
4. Simpan file.

Anon/publishable key memang digunakan oleh aplikasi browser, tetapi keamanan data harus dijamin oleh RLS pada `schema.sql`. Jangan pernah memasukkan service-role/secret key ke file frontend.

## C. Buat akun administrator pertama
1. Di Supabase Dashboard, buka **Authentication → Users → Add user**.
2. Buat akun admin menggunakan email sekolah yang dikuasai sekolah dan kata sandi kuat.
3. Salin UUID user tersebut dari daftar Auth Users.
4. Di SQL Editor jalankan perintah berikut dengan mengganti UUID dan nama:
   ```sql
   insert into public.profiles (id, full_name, role)
   values ('UUID-AKUN-ADMIN', 'Administrator Perpustakaan', 'admin')
   on conflict (id) do update set full_name=excluded.full_name, role='admin';
   ```
5. Login melalui aplikasi memakai email dan password tadi.
6. Buat akun pustakawan/guru/siswa melalui Authentication → Users. Untuk setiap akun, tambahkan profil lewat SQL Editor. Contoh:
   ```sql
   insert into public.profiles (id, full_name, role, class_name)
   values ('UUID-AKUN-SISWA', 'Siswa Contoh', 'student', '5A');
   ```
   Peran yang diizinkan: `admin`, `librarian`, `teacher`, `student`. Hanya admin tepercaya yang boleh mengubah role.

## D. Terbitkan website gratis
Pilihan mudah adalah GitHub Pages:
1. Buat repository GitHub baru, misalnya `perpus-cerdas-sdn13`.
2. Upload `index.html` ke root repository. README dan schema boleh ikut diunggah, tetapi jangan mengunggah password atau secret key.
3. Repository → **Settings → Pages** → Deploy from a branch → `main` / root → Save.
4. Tunggu URL Pages muncul. Buka URL tersebut melalui HTTPS dan uji login.
5. Tambahkan domain sekolah bila sudah tersedia dan DNS dapat dikelola.

GitHub Pages hanya menyajikan file statis. Database dan login berjalan di Supabase. Ketersediaan paket gratis, kuota, dan syarat layanan dapat berubah; periksa ketentuan terbaru sebelum dipakai.

## E. Pengujian penerimaan
- [ ] Login admin berhasil.
- [ ] Akun tanpa login tidak dapat membaca data database melalui aplikasi.
- [ ] Admin/pustakawan dapat menambah dan mengubah buku.
- [ ] Guru/siswa tidak dapat mengubah katalog.
- [ ] Peminjaman dan pengembalian dapat dicatat oleh pustakawan.
- [ ] Siswa hanya dapat membaca jurnal miliknya; guru/staf sesuai aturan dapat membaca jurnal untuk pendampingan.
- [ ] Jurnal siswa tersimpan setelah logout/login ulang.
- [ ] Ekspor CSV berfungsi.
- [ ] Uji akses langsung dan kebijakan RLS di Supabase.
- [ ] Uji pada komputer dan ponsel.

## Batasan yang perlu diketahui
- Untuk saat ini, file buku tidak diunggah ke penyimpanan privat; katalog menyimpan URL HTTPS yang legal/diizinkan.
- Aplikasi ini belum mengirim notifikasi, belum mengelola barcode, dan belum memiliki kuis/gamifikasi.
- Transaksi peminjaman menyimpan nama peminjam sebagai teks; sebelum penggunaan skala besar, sebaiknya gunakan foreign key ke profil siswa dan perbaiki alur transaksi.
- Karena aplikasi menangani data anak, sebelum operasional lakukan tinjauan keamanan, privasi, kebijakan sekolah, persetujuan yang relevan, dan uji RLS dengan akun berbeda. Batasi data yang dikumpulkan.

## Cara uji lokal
Buka `index.html` di browser setelah URL/key diisi. Untuk deployment nyata, uji dari HTTPS GitHub Pages. Jangan memakai data pribadi siswa asli sebelum pengujian keamanan diselesaikan.
